public class ILS extends Coin {

    final double shekel = 0.28;


    @Override
    public double getValue() {
        return shekel;
    }
}


