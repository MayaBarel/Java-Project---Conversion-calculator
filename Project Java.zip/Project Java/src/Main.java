import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

//    Getting the value of shekel


        ILS shach = new ILS();

        double x = shach.getValue();


//    Getting the value of dollar

        USD usdDullar = new USD();

        double y = usdDullar.getValue();

//      Array List and Scanner

        ArrayList<Double> list = new ArrayList<>();
        Scanner scanner = new Scanner(System.in);
        String more;


        //        First screen (Welcome Screen)

        System.out.println("Welcome to currency converter");

        do {

            // options 1/2

            System.out.println("Please choose an option (1/2):  ");
            System.out.println("1.Dollars to Shekels");
            System.out.println("2.Shekels to Dollars");


            try {
                double userNameAnswer = scanner.nextDouble();


                // insist to get ONLY 1 or 2
                while (userNameAnswer != 1 && userNameAnswer != 2) {
                    System.out.println("Invalid Choice, please try again");
                    userNameAnswer = scanner.nextInt();
                }

                // here we are sure that userNameAnswer MUST be 1 or 2

                System.out.println("Please enter an amount to convert");
                double amount1 = scanner.nextDouble();
                double calculation;

                if (userNameAnswer == 1) {
                    calculation = amount1 * usdDullar.getValue();
                    System.out.format("Your amount in shekel is : %.3f%n", calculation);
                } else {
                    calculation = amount1 * shach.getValue();
                    System.out.format("Your amount in dollar is : %.3f%n", calculation);
                }
                list.add(calculation);

            } catch (Exception e) {
                System.out.println("Something went wrong.");
                scanner.nextLine();
            }
            System.out.println("Do you want to calculate again? Y/N");
            more = scanner.nextLine();

        }
        while (more.equalsIgnoreCase("Y")) ;


        //  End Screen
        System.out.println("Thanks for using our currency converter");
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }

    }
}



