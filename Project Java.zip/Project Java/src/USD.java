public class USD extends Coin {

      final double dollar = 3.52 ;

    @Override
    public double getValue() {
        return dollar;
    }
}
