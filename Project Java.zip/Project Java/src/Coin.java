public abstract class Coin{


    public abstract double getValue() ;
}


